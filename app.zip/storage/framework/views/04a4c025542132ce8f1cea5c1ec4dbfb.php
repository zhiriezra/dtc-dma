    <!-- resources/views/livewire/digital-maturity-assessment.blade.php -->
<div class="max-w-4xl mx-auto p-6">

    <div class="mb-8">
        <div class="flex items-center justify-between">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = array_keys($sections); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sectionName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col items-center">
                    <div class="relative">
                        <div class="w-10 h-10 rounded-full flex items-center justify-center <?php echo e($index <= $currentSection ? 'bg-red-500 text-white' : 'bg-gray-300 text-gray-600'); ?>">
                            <?php echo e($index + 1); ?>

                        </div>
                        <!--[if BLOCK]><![endif]--><?php if($index < count($sections) - 1): ?>
                            <div class="absolute w-full h-1 bg-<?php echo e($index < $currentSection ? 'red' : 'gray'); ?>-300 top-1/2 left-full"></div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <span class="text-sm mt-2 text-center <?php echo e($index <= $currentSection ? 'text-red-500 font-medium' : 'text-gray-500'); ?>">
                        <?php
                            $words = explode(' ', $sectionName);
                            $truncated = implode(' ', array_slice($words, 0, 3));
                        ?>
                        <?php echo e($truncated); ?>

                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <!--[if BLOCK]><![endif]--><?php if(!$showResults): ?>
        <div class="mb-8">
            <h2 class="text-2xl font-bold mb-4 text-red-500"><?php echo e($currentSectionName); ?></h2>
            <div class="space-y-6">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sections[$currentSectionName]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white p-6 rounded-lg shadow">
                        <p class="text-lg mb-4 font-semibold"><?php echo e($question['question']); ?>

                            <small>
                                <!--[if BLOCK]><![endif]--><?php if(isset($question['instruction'])): ?>
                                    <?php echo e($question['instruction']); ?>

                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </small>
                        </p>

                        <!--[if BLOCK]><![endif]--><?php if($question['type'] === 'radio'): ?>
                            <div class="space-y-2">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex items-center">
                                        <input type="radio"
                                               wire:model="answers.<?php echo e($question['id']); ?>"
                                               value="<?php echo e($option['text']); ?>"
                                               class="mr-2">
                                        <?php echo e($option['text']); ?>

                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                        <?php elseif($question['type'] === 'checkbox'): ?>
                            <div class="space-y-2">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex items-center">
                                        <input type="checkbox"
                                               wire:model="answers.<?php echo e($question['id']); ?>"
                                               value="<?php echo e($option['text']); ?>"
                                               class="mr-2">
                                        <?php echo e($option['text']); ?>

                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                        <?php elseif($question['type'] === 'likert'): ?>
                            <div class="grid grid-cols-5 gap-4 text-center">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex flex-col items-center">
                                        <input type="radio"
                                               wire:model="answers.<?php echo e($question['id']); ?>"
                                               value="<?php echo e($option['text']); ?>"
                                               class="mb-2">
                                        <?php echo e($option['text']); ?>

                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                        <?php elseif($question['type'] === 'select'): ?>
                            <select wire:model="answers.<?php echo e($question['id']); ?>"
                                    class="w-full p-2 border rounded">
                                <option value="">Select an option</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option['text']); ?>">
                                        <?php echo e($option['text']); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="flex justify-between">
            <!--[if BLOCK]><![endif]--><?php if($currentSection > 0): ?>
                <button wire:click="previousSection"
                        class="bg-gray-500 text-white px-4 py-2 rounded">
                    Previous
                </button>
            <?php else: ?>
                <div></div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <button wire:click="nextSection"
                    class="bg-red-500 text-white px-4 py-2 rounded">
                <?php echo e($currentSection < count($sections) - 1 ? 'Next' : 'View Results'); ?>

            </button>
        </div>

    <?php else: ?>
        <div class="space-y-8">
            <h2 class="text-2xl font-bold mb-6">Digital Maturity Assessment Results</h2>

            <!-- Overall Score Card with dynamic colors -->
            <?php
                $bgColor = match($overallScore['level']) {
                    'Advanced' => 'bg-green-50 border-green-200',
                    'Established' => 'bg-blue-50 border-blue-200',
                    'Developing' => 'bg-yellow-50 border-yellow-200',
                    'Basic' => 'bg-orange-50 border-orange-200',
                    default => 'bg-red-50 border-red-200'
                };

                $textColor = match($overallScore['level']) {
                    'Advanced' => 'text-green-800',
                    'Established' => 'text-blue-800',
                    'Developing' => 'text-yellow-800',
                    'Basic' => 'text-orange-800',
                    default => 'text-red-800'
                };

                $progressColor = match($overallScore['level']) {
                    'Advanced' => 'bg-green-600',
                    'Established' => 'bg-blue-600',
                    'Developing' => 'bg-yellow-500',
                    'Basic' => 'bg-orange-500',
                    default => 'bg-red-500'
                };

                $scoreColor = match($overallScore['level']) {
                    'Advanced' => 'text-green-600',
                    'Established' => 'text-blue-600',
                    'Developing' => 'text-yellow-600',
                    'Basic' => 'text-orange-600',
                    default => 'text-red-600'
                };
            ?>

            <div class="p-6 rounded-lg shadow-lg border-2 <?php echo e($bgColor); ?>">
                <h3 class="text-2xl font-bold mb-4 <?php echo e($textColor); ?>">Overall Digital Maturity</h3>
                <div class="space-y-4">
                    <div class="flex justify-between items-center">
                        <span class="text-lg">Overall Score:</span>
                        <span class="text-2xl font-bold <?php echo e($scoreColor); ?>"><?php echo e($overallScore['percentage']); ?>%</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-3">
                        <div class="<?php echo e($progressColor); ?> h-3 rounded-full"
                            style="width: <?php echo e($overallScore['percentage']); ?>%"></div>
                    </div>
                    <div class="text-center mt-4">
                        <span class="text-lg">Maturity Level:</span>
                        <span class="text-xl font-bold ml-2 <?php echo e($textColor); ?>"><?php echo e($overallScore['level']); ?></span>
                    </div>
                </div>
            </div>

            <!-- Section Scores -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectionName => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $level = $this->getMaturityLevel($score['percentage']);
                        $sectionProgressColor = match($level) {
                            'Advanced' => 'bg-green-500',
                            'Established' => 'bg-blue-500',
                            'Developing' => 'bg-yellow-500',
                            'Basic' => 'bg-orange-500',
                            default => 'bg-red-500'
                        };
                        $sectionTextColor = match($level) {
                            'Advanced' => 'text-green-500',
                            'Established' => 'text-blue-500',
                            'Developing' => 'text-yellow-500',
                            'Basic' => 'text-orange-500',
                            default => 'text-red-500'
                        };
                    ?>

                    <div class="bg-white p-6 rounded-lg shadow">
                        <h3 class="text-xl font-semibold mb-4"><?php echo e($sectionName); ?></h3>
                        <div class="space-y-2">
                            <div class="flex justify-between items-center">
                                <span>Score: <?php echo e($score['score']); ?> / <?php echo e($score['max']); ?></span>
                                <span class="font-bold <?php echo e($sectionTextColor); ?>"><?php echo e($score['percentage']); ?>%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2.5">
                                <div class="<?php echo e($sectionProgressColor); ?> h-2.5 rounded-full"
                                    style="width: <?php echo e($score['percentage']); ?>%"></div>
                            </div>
                            <p class="mt-2">
                                Maturity Level:
                                <span class="font-bold <?php echo e($sectionTextColor); ?>">
                                    <?php echo e($level); ?>

                                </span>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="mt-8 flex space-x-4">
                <button onclick="window.print()"
                        class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                    Print Results
                </button>
                <button onclick="window.location.reload()"
                        class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Start New Assessment
                </button>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Users\Mamman Paul\Herd\dma-laravel\resources\views/livewire/digital-maturity-assessment.blade.php ENDPATH**/ ?>