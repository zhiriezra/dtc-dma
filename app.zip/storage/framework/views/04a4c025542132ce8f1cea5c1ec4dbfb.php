<!-- resources/views/livewire/digital-maturity-assessment.blade.php -->
<div class="max-w-4xl mx-auto p-6">
    <!--[if BLOCK]><![endif]--><?php if($currentSection < 0): ?>
        <!-- Basic Information Section -->
        <div class="bg-white p-6 rounded-lg shadow-lg mb-8">
            <h2 class="text-2xl font-bold mb-6 text-red-500">Preliminary Information</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block mb-2">Respondent Name *</label>
                    <input type="text" wire:model="basicInfo.respondent_name" class="w-full border rounded p-2">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.respondent_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">Business Name *</label>
                    <input type="text" wire:model="basicInfo.business_name" class="w-full border rounded p-2">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">Gender *</label>
                    <select wire:model="basicInfo.gender" class="w-full border rounded p-2">
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">Phone Number *</label>
                    <input type="tel" wire:model="basicInfo.phone_number" class="w-full border rounded p-2">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">Respondent Email *</label>
                    <input type="email" wire:model="basicInfo.email" class="w-full border rounded p-2">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">State *</label>
                    <select wire:model="basicInfo.state" class="w-full border rounded p-2">
                        <option value="">Select State</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($state); ?>"><?php echo e($state); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                

                <div>
                    <label class="block mb-2">Business Sector *</label>
                    <select wire:model="basicInfo.business_sector" class="w-full border rounded p-2">
                        <option value="">Select Sector</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $businessSectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sector); ?>"><?php echo e($sector); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.business_sector'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">Employee Count *</label>
                    <input type="number" wire:model="basicInfo.employee_count" class="w-full border rounded p-2">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.employee_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">Role in Business *</label>
                    <input type="text" wire:model="basicInfo.role" class="w-full border rounded p-2">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">Years in Business *</label>
                    <input type="number" wire:model="basicInfo.years_in_business" class="w-full border rounded p-2">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.years_in_business'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">Staff Size *</label>
                    <select wire:model="basicInfo.staff_size" class="w-full border rounded p-2">
                        <option value="">Select Staff Size</option>
                        <option value="1-9">Micro (1–9 employees)</option>
                        <option value="10-49">Small (10–49 employees)</option>
                        <option value="50-249">Medium (50–249 employees)</option>
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.staff_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div>
                    <label class="block mb-2">Digital Advisor</label>
                    <input type="text" wire:model="basicInfo.digital_advisor" class="w-full border rounded p-2">
                </div>

                <div class="col-span-2">
                    <label class="flex items-center space-x-2">
                        <input type="checkbox" wire:model="basicInfo.multiple_states">
                        <span>Do you operate in multiple states?</span>
                    </label>
                    <!--[if BLOCK]><![endif]--><?php if($basicInfo['multiple_states']): ?>
                        <div class="mt-2">
                            <input type="text"
                                   wire:model="basicInfo.operating_states"
                                   placeholder="List the states (comma separated)"
                                   class="w-full border rounded p-2">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['operating_states'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="col-span-2">
                    <label class="flex items-center space-x-2">
                        <input type="checkbox" wire:model="basicInfo.has_disability">
                        <span>Do you have any disability?</span>
                    </label>
                </div>

                <div class="col-span-2">
                    <label class="flex items-center space-x-2">
                        <input type="checkbox" wire:model="basicInfo.consent_given">
                        <span>I consent to participate in this assessment *</span>
                    </label>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['basicInfo.consent_given'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <div class="mt-6">
                <button wire:click="startAssessment"
                        class="bg-red-500 text-white px-6 py-2 rounded hover:bg-red-600">
                    Start Assessment
                </button>
            </div>
        </div>
    <?php else: ?>
        <!-- Assessment Progress Bar -->
        <div class="mb-8">
            <div class="flex items-center justify-between">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = array_keys($sections); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sectionName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-col items-center">
                        <div class="relative">
                            <div class="w-10 h-10 rounded-full flex items-center justify-center <?php echo e($index <= $currentSection ? 'bg-red-500 text-white' : 'bg-gray-300 text-gray-600'); ?>">
                                <?php echo e($index + 1); ?>

                            </div>
                            <!--[if BLOCK]><![endif]--><?php if($index < count($sections) - 1): ?>
                                <div class="absolute w-full h-1 bg-<?php echo e($index < $currentSection ? 'red' : 'gray'); ?>-300 top-1/2 left-full"></div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <span class="text-sm mt-2 text-center <?php echo e($index <= $currentSection ? 'text-red-500 font-medium' : 'text-gray-500'); ?>">
                            <?php
                                $words = explode(' ', $sectionName);
                                $truncated = implode(' ', array_slice($words, 0, 3));
                            ?>
                            <?php echo e($truncated); ?>

                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <!--[if BLOCK]><![endif]--><?php if(!$showResults): ?>
            <!-- Assessment Questions -->
            <div class="mb-8">
                <h2 class="text-2xl font-bold mb-4 text-red-500"><?php echo e($currentSectionName); ?></h2>
                <div class="space-y-6">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sections[$currentSectionName]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white p-6 rounded-lg shadow">
                            <p class="text-lg mb-4 font-semibold"><?php echo e($question['question']); ?>

                                <small>
                                    <!--[if BLOCK]><![endif]--><?php if(isset($question['instruction'])): ?>
                                        <?php echo e($question['instruction']); ?>

                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </small>
                            </p>

                            <!--[if BLOCK]><![endif]--><?php if($question['type'] === 'radio'): ?>
                                <div class="space-y-2">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center">
                                            <input type="radio"
                                                   wire:model="answers.<?php echo e($question['id']); ?>"
                                                   value="<?php echo e($option['text']); ?>"
                                                   class="mr-2">
                                            <?php echo e($option['text']); ?>

                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                            <?php elseif($question['type'] === 'checkbox'): ?>
                                <div class="space-y-2">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center">
                                            <input type="checkbox"
                                                   wire:model="answers.<?php echo e($question['id']); ?>"
                                                   value="<?php echo e($option['text']); ?>"
                                                   class="mr-2">
                                            <?php echo e($option['text']); ?>

                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                            <?php elseif($question['type'] === 'select'): ?>
                                <select wire:model="answers.<?php echo e($question['id']); ?>"
                                        class="w-full p-2 border rounded">
                                    <option value="">Select an option</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($option['text']); ?>">
                                            <?php echo e($option['text']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <!-- Navigation Buttons -->
            <div class="flex justify-between">
                <!--[if BLOCK]><![endif]--><?php if($currentSection > 0): ?>
                    <button wire:click="previousSection"
                            class="bg-gray-500 text-white px-4 py-2 rounded">
                        Previous
                    </button>
                <?php else: ?>
                    <div></div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <button wire:click="nextSection"
                        class="bg-red-500 text-white px-4 py-2 rounded">
                    <?php echo e($currentSection < count($sections) - 1 ? 'Next' : 'View Results'); ?>

                </button>
            </div>

        <?php else: ?>
            <!-- Results Section -->
            <div class="space-y-8">
                <h2 class="text-2xl font-bold">Digital Maturity Assessment Results: <?php echo e($basicInfo['business_name']); ?></h2>
                <!-- Overall Score Card -->
                <?php
                    $bgColor = match($overallScore['level']) {
                        'Leader/Transformative' => 'bg-green-50 border-green-300',
                        'Advanced/Strategic' => 'bg-green-50 border-green-200',
                        'Competent/Defined' => 'bg-blue-50 border-blue-200',
                        'Developing/Emerging' => 'bg-yellow-50 border-yellow-200',
                        'Novice/Beginner' => 'bg-orange-50 border-orange-200',
                        default => 'bg-red-50 border-red-200'
                    };

                    $textColor = match($overallScore['level']) {
                        'Leader/Transformative' => 'text-green-600',
                        'Advanced/Strategic' => 'text-green-500',
                        'Competent/Defined' => 'text-blue-800',
                        'Developing/Emerging' => 'text-yellow-800',
                        'Novice/Beginner' => 'text-orange-800',
                        default => 'text-red-800'
                    };

                    $progressColor = match($overallScore['level']) {
                        'Leader/Transformative' => 'bg-green-600',
                        'Advanced/Strategic' => 'bg-green-500',
                        'Competent/Defined' => 'bg-blue-600',
                        'Developing/Emerging' => 'bg-yellow-500',
                        'Novice/Beginner' => 'bg-orange-500',
                        default => 'bg-red-500'
                    };

                    $scoreColor = match($overallScore['level']) {
                        'Leader/Transformative' => 'text-green-600',
                        'Advanced/Strategic' => 'text-green-500',
                        'Competent/Defined' => 'text-blue-600',
                        'Developing/Emerging' => 'text-yellow-600',
                        'Novice/Beginner' => 'text-orange-600',
                        default => 'text-red-600'
                    };
                ?>

                <div class="p-6 rounded-lg shadow-lg border-2 <?php echo e($bgColor); ?>">
                    <h3 class="text-2xl font-bold mb-4 <?php echo e($textColor); ?>">Overall Digital Maturity</h3>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center">
                            <span class="text-lg">Overall Score:</span>
                            <span class="text-2xl font-bold <?php echo e($scoreColor); ?>"><?php echo e($overallScore['percentage']); ?>%</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-3">
                            <div class="<?php echo e($progressColor); ?> h-3 rounded-full"
                                style="width: <?php echo e($overallScore['percentage']); ?>%"></div>
                        </div>
                    </div>
                    <div class="text-center mt-4">
                        <span class="text-lg">Maturity Level:</span>
                        <span class="text-xl font-bold ml-2 <?php echo e($textColor); ?>"><?php echo e($overallScore['level']); ?></span>
                    </div>
                </div>
            </div>

            <!-- Section Scores -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectionName => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $level = $this->getMaturityLevel($score['percentage']);
                        $sectionProgressColor = match($level) {
                            'Leader/Transformative' => 'bg-green-600',
                            'Advanced/Strategic' => 'bg-green-500',
                            'Competent/Defined' => 'bg-blue-500',
                            'Developing/Emerging' => 'bg-yellow-500',
                            'Novice/Beginner' => 'bg-orange-500',
                            default => 'bg-red-500'
                        };
                        $sectionTextColor = match($level) {
                            'Leader/Transformative' => 'text-green-600',
                            'Advanced/Strategic' => 'text-green-500',
                            'Competent/Defined' => 'text-blue-500',
                            'Developing/Emerging' => 'text-yellow-500',
                            'Novice/Beginner' => 'text-orange-500',
                            default => 'text-red-500'
                        };
                    ?>

                    <div class="bg-white p-6 rounded-lg shadow">
                        <h3 class="text-xl font-semibold mb-4"><?php echo e($sectionName); ?></h3>
                        <div class="space-y-2">
                            <div class="flex justify-between items-center">
                                <span>Score: <?php echo e($score['score']); ?> / <?php echo e($score['max']); ?></span>
                                <span class="font-bold <?php echo e($sectionTextColor); ?>"><?php echo e($score['percentage']); ?>%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2.5">
                                <div class="<?php echo e($sectionProgressColor); ?> h-2.5 rounded-full"
                                    style="width: <?php echo e($score['percentage']); ?>%"></div>
                            </div>
                            <p class="mt-2">
                                Maturity Level:
                                <span class="font-bold <?php echo e($sectionTextColor); ?>">
                                    <?php echo e($level); ?>

                                </span>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Action Buttons -->
            <div class="mt-8 flex flex-wrap gap-4">
                <button onclick="window.print()"
                        class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                    Print Results
                </button>
                <button onclick="window.location.reload()"
                        class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Start New Assessment
                </button>

            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Users\Mamman Paul\Herd\dma-laravel\resources\views/livewire/digital-maturity-assessment.blade.php ENDPATH**/ ?>