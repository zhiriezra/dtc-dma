<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

  </head>
  <body>

    <nav class="bg-red-500 text-white p-4">
        <div class="container mx-auto gap-4 flex items-center">
            <a href="/">
                <img src="<?php echo e(asset('logo.webp')); ?>" alt="">
            </a>
            <h1 class="font-bold text-2xl">Digital Maturity Assessment - DTC Nigeria</h1>
        </div>

    </nav>

    <div class="">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('digital-maturity-assessment');

$__html = app('livewire')->mount($__name, $__params, 'lw-2698607579-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


  </body>
</html>
<?php /**PATH C:\Users\Mamman Paul\Herd\dma-laravel\resources\views\welcome.blade.php ENDPATH**/ ?>